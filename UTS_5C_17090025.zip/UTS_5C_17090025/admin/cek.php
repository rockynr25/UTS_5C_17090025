<?php 
if(!isset($_SESSION['uname'])){
	header("location:../index.php");
}
?>